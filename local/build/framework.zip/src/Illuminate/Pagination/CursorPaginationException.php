<?php

namespace Illuminate\Pagination;

use RuntimeException;

class CursorPaginationException extends RuntimeException
{
    //
}
